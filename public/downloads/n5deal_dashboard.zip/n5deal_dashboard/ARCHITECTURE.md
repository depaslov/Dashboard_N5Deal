# 🏛️ Architecture — N5Deal Dashboard

Technical overview of the Phase 1 MVP.

---

## 🎯 System Overview

N5Deal Dashboard is a **multi-tenant marketing workspace** where teams manage Ideal Customer Profiles (ICPs) and generate AI-powered marketing briefs for specific formats (articles, catalogs, LinkedIn, Telegram).

**Key constraints:**
- Multi-project isolation — users only see data for projects they're members of
- Role-based access — Admin/Member within each project
- LLM-powered content generation with streaming (SSE)
- Server-first rendering (Next.js App Router + server components)

---

## 🧱 Tech Stack

| Layer | Technology | Purpose |
|-------|-----------|---------|
| Framework | **Next.js 14** (App Router) | SSR, routing, API routes |
| Language | **TypeScript 5** | Type safety |
| Database | **PostgreSQL 14+** | Primary data store |
| ORM | **Prisma 6** | Type-safe DB access |
| Auth | **NextAuth.js v4** | Credentials provider + JWT sessions |
| Styling | **Tailwind CSS 3** | Design tokens + utilities |
| UI primitives | **Radix UI** + **shadcn/ui** | Accessible components |
| Animations | **framer-motion** | Stat card counts, transitions |
| AI | **Abacus.AI LLM API** | Content generation (streaming) |
| Validation | **Zod** | Runtime input validation |
| Fonts | **Plus Jakarta Sans**, **DM Sans** | Typography |

---

## 📁 Directory Layout

```
nextjs_space/
├── app/
│   ├── (app)/                    # Grouped route — auth-protected
│   │   ├── layout.tsx            # Shared dashboard shell (sidebar + topbar)
│   │   ├── dashboard/
│   │   │   └── page.tsx          # Executive overview
│   │   ├── icps/
│   │   │   ├── page.tsx          # List view
│   │   │   ├── new/page.tsx      # Create
│   │   │   └── [id]/page.tsx     # Detail / edit
│   │   ├── content/
│   │   │   ├── page.tsx          # History
│   │   │   ├── new/page.tsx      # Generator (SSE)
│   │   │   └── [id]/page.tsx     # View brief
│   │   └── settings/
│   │       └── page.tsx          # Profile + project + team
│   ├── api/
│   │   ├── auth/[...nextauth]/   # NextAuth handlers
│   │   ├── signup/               # User registration
│   │   ├── profile/              # PATCH profile
│   │   ├── projects/             # GET/POST projects
│   │   │   └── [id]/
│   │   │       ├── route.ts      # PATCH/DELETE
│   │   │       └── members/     # Team CRUD
│   │   ├── icps/                 # ICP CRUD
│   │   └── content/              # Content CRUD + /generate (SSE)
│   ├── login/                    # Sign-in page
│   ├── signup/                   # Sign-up page
│   ├── layout.tsx                # Root layout (providers, fonts)
│   ├── globals.css               # Tailwind + CSS variables
│   └── page.tsx                  # Marketing landing
├── components/
│   ├── app/                      # Business components
│   │   ├── dashboard-shell.tsx   # Sidebar + topbar wrapper
│   │   ├── stat-card.tsx         # Animated KPI card
│   │   ├── icp-form.tsx          # Create/edit ICP
│   │   ├── content-generator.tsx # SSE streaming client
│   │   └── page-header.tsx
│   ├── ui/                       # shadcn/ui primitives (button, card, ...)
│   └── providers/                # SessionProvider, ThemeProvider
├── lib/
│   ├── auth.ts                   # NextAuth config (exports authOptions)
│   ├── db.ts                     # Prisma client singleton
│   ├── project.ts                # Project access helpers
│   └── utils.ts                  # cn(), formatting helpers
├── prisma/
│   └── schema.prisma             # Database schema
├── scripts/
│   ├── seed.ts                   # Sample data
│   └── safe-seed.ts              # Seed wrapper (blocks delete ops)
├── hooks/
│   └── use-toast.ts              # Toast notifications hook
└── types/
    └── next-auth.d.ts            # Session type augmentation
```

---

## 🗄️ Database Schema

```prisma
User {
  id, email, passwordHash, name, role, createdAt
  ownedProjects: Project[]
  memberships:   ProjectMember[]
  contents:      GeneratedContent[]
}

Project {
  id, name, companyName, description, ownerId, createdAt
  owner:   User
  members: ProjectMember[]
  icps:    ICP[]
  contents: GeneratedContent[]
}

ProjectMember {
  id, projectId, userId, role ('admin' | 'member')
  @@unique([projectId, userId])
}

ICP {
  id, projectId, name, industry, companySize,
  painPoints: String[], goals: String[],
  demographics, budgetRange, decisionProcess,
  createdAt, updatedAt
}

GeneratedContent {
  id, projectId, createdById,
  contentType ('article' | 'catalog' | 'linkedin' | 'telegram'),
  topic, targetAudience, keyMessages, tone,
  generatedBrief: Text, createdAt
}
```

**Key design decisions:**
- `painPoints` and `goals` use `String[]` (Postgres array) — avoids extra join table
- `GeneratedContent.generatedBrief` uses `@db.Text` for long outputs
- Cascade deletes: deleting a Project removes all its ICPs, members, content

---

## 🔐 Authentication Flow

1. User signs up → `POST /api/signup` → bcrypt-hashed password stored
2. User signs in → NextAuth CredentialsProvider validates email/password
3. JWT issued containing `user.id` and `user.role`
4. Session populated via `callbacks.jwt` + `callbacks.session` in `lib/auth.ts`
5. Protected pages use `getServerSession(authOptions)` → redirect to `/login` if null
6. API routes validate via the same `getServerSession`

---

## 🏢 Multi-Project Isolation

Every query that touches ICPs or Content must first verify project access:

```ts
import { assertProjectAccess } from '@/lib/project'

const hasAccess = await assertProjectAccess(userId, projectId)
if (!hasAccess) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
```

`getOrCreateCurrentProject(userId)` returns the user's default workspace (creates one if none exists) — used across all protected pages.

---

## 🤖 AI Content Generation (SSE Streaming)

**Endpoint:** `POST /api/content/generate`

**Flow:**
1. Client (`components/app/content-generator.tsx`) submits form with `contentType`, `topic`, `targetAudience`, `keyMessages`, `tone`
2. Server validates input + project access
3. Server builds a prompt tailored to the `contentType` (different system prompts for article/catalog/linkedin/telegram)
4. Server opens a streaming response using Server-Sent Events (SSE)
5. Heartbeat every ~10s prevents proxy timeouts
6. Chunks arrive as `data: {"delta": "…"}` events
7. On completion, server persists final output to `GeneratedContent` and emits `data: {"done": true, "id": "…"}`
8. Client appends deltas to a textarea, redirects to `/content/[id]` on completion

---

## 🎨 Design System

Defined in `app/globals.css` via CSS custom properties:

```css
--background: 210 20% 98%;       /* off-white */
--foreground: 222 47% 11%;       /* deep slate */
--primary:    222 47% 15%;       /* corporate navy */
--accent:     213 94% 48%;       /* electric blue */
--radius:     2px;               /* square corners */
```

- Headings: **Plus Jakarta Sans** (tight tracking)
- Body: **DM Sans**
- Dark mode: shipped, toggled via `next-themes`
- Aesthetic: corporate, neutral, minimal rounded corners

See `nextjs_space/STYLE_GUIDE.md` for component conventions.

---

## 🔄 Data Flow Example: Creating an ICP

```
User clicks "New ICP"
    ↓
/icps/new  →  ICPForm (client component)
    ↓  submits
POST /api/icps { name, industry, painPoints[], ... }
    ↓
[api/icps/route.ts]
    ├─ getServerSession → userId
    ├─ getOrCreateCurrentProject(userId) → projectId
    ├─ assertProjectAccess(userId, projectId)
    ├─ validate payload with Zod
    └─ prisma.iCP.create({ data })
    ↓
Redirect to /icps
    ↓
Server re-renders list via Prisma query
```

---

## 🔮 Planned Extensions (Future Phases)

| Module | Phase | Notes |
|--------|-------|-------|
| SEO Tracker | 2 | Keyword positions, backlinks, CPL |
| Google Analytics integration | 2 | GA4 Data API via OAuth |
| LinkedIn Strategy module | 3 | Content calendar + analytics |
| Telegram Channel module | 3 | Telegram Bot API integration |
| Custom reports + PDF export | 4 | Playwright-based PDF generator |
| Compliance Center | 4 | Regulatory content approval workflow |

---

## 📏 Coding Conventions

- **Server components by default** — only opt into `"use client"` when needed (forms, streaming, interactivity)
- **Pages** declare `export const dynamic = 'force-dynamic'` when reading session/DB
- **Form validation** — Zod schemas in API route files (not shared unless reused)
- **Styling** — Tailwind utilities, avoid raw CSS; extract shared styles into UI primitives
- **Imports** — use `@/` alias for everything above `lib/`, `components/`, `app/`
- **No `any`** — prefer `unknown` + narrowing; `any` only as a last-resort for 3rd-party adapter types

---

## 🧪 Testing

_Not included in Phase 1 MVP._ Planned for Phase 5:
- **Vitest** for unit tests
- **Playwright** for E2E
- **Prisma test database** via `docker-compose`

---

Last updated: Phase 1 MVP
