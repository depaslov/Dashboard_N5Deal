# N5Deal AI Marketing Dashboard

A professional, AI-powered marketing dashboard for managing Ideal Customer Profiles (ICPs), generating content briefs via LLM, and coordinating multi-project marketing workflows.

**Stack:** Next.js 14 · TypeScript · PostgreSQL · Prisma · NextAuth · Tailwind CSS · Abacus.AI LLM API

---

## 🚀 Quick Start (Local Setup)

👉 **macOS guide (recommended):** see [`SETUP_MACOS.md`](./SETUP_MACOS.md) ⭐
👉 **Generic guide (Linux / Windows):** see [`LOCAL_SETUP.md`](./LOCAL_SETUP.md)

### TL;DR

```bash
# 1. Install dependencies
cd nextjs_space
yarn install

# 2. Configure environment
cp .env.example .env
# edit .env — set DATABASE_URL, NEXTAUTH_SECRET, ABACUSAI_API_KEY

# 3. Set up database
yarn prisma generate
yarn prisma db push
yarn prisma db seed

# 4. Run development server
yarn dev
```

Open **http://localhost:3000**

### Default Credentials
```
Email:    john@doe.com
Password: johndoe123
```

---

## 📁 Project Structure

```
n5deal_dashboard/
├── nextjs_space/              # Next.js application root
│   ├── app/                   # App Router pages & API routes
│   │   ├── (app)/             # Protected dashboard routes
│   │   │   ├── dashboard/     # Main overview
│   │   │   ├── icps/          # ICP management
│   │   │   ├── content/       # Content Studio (AI)
│   │   │   └── settings/      # Profile & team
│   │   ├── api/               # REST API routes
│   │   ├── login/
│   │   ├── signup/
│   │   └── page.tsx           # Landing page
│   ├── components/
│   │   ├── app/               # Feature components
│   │   ├── ui/                # shadcn/ui primitives
│   │   └── providers/
│   ├── lib/
│   │   ├── auth.ts            # NextAuth config
│   │   ├── db.ts              # Prisma client
│   │   └── project.ts         # Project access logic
│   ├── prisma/
│   │   └── schema.prisma      # DB schema
│   ├── scripts/
│   │   ├── seed.ts            # Seed sample data
│   │   └── safe-seed.ts       # Seed wrapper (prevents deletes)
│   └── package.json
├── README.md                  # This file
├── LOCAL_SETUP.md             # Detailed local-setup guide
├── ARCHITECTURE.md            # Technical architecture
└── .env.example               # Env template
```

---

## 🏗️ Architecture Overview

See [`ARCHITECTURE.md`](./ARCHITECTURE.md) for a full technical overview.

### Core Modules (Phase 1 MVP)

| Module | Description |
|--------|-------------|
| **Dashboard** | Executive overview with KPIs and recent activity |
| **ICP Management** | Full CRUD for Ideal Customer Profiles with pain points, goals, budget, decision process |
| **Content Studio** | AI-powered brief generator for Articles, Catalogs, LinkedIn, Telegram |
| **Settings** | User profile, project management, team invitations |

### Data Model

```
User ──┬──< Project (owner)
       └──< ProjectMember >── Project
                                 ├──< ICP
                                 └──< GeneratedContent
```

---

## 🔑 Required Credentials

| Variable | Description | Where to get |
|----------|-------------|--------------|
| `DATABASE_URL` | PostgreSQL connection string | Local Postgres / Supabase / Railway / Neon |
| `NEXTAUTH_SECRET` | Random 32+ char secret | Generate with `openssl rand -base64 32` |
| `NEXTAUTH_URL` | Base URL of the app | `http://localhost:3000` locally |
| `ABACUSAI_API_KEY` | LLM API key (for Content Studio) | [Abacus.AI](https://abacus.ai/) |

---

## 📜 Scripts

```bash
yarn dev                 # Start dev server
yarn build               # Production build
yarn start               # Run production build
yarn lint                # ESLint

yarn prisma studio       # Visual DB editor
yarn prisma generate     # Regenerate Prisma client
yarn prisma db push      # Sync schema to database
yarn prisma db seed      # Seed sample data
```

---

## 📚 Documentation

- [`LOCAL_SETUP.md`](./LOCAL_SETUP.md) — step-by-step local installation
- [`ARCHITECTURE.md`](./ARCHITECTURE.md) — technical architecture & conventions
- [`nextjs_space/STYLE_GUIDE.md`](./nextjs_space/STYLE_GUIDE.md) — design system

---

## 🗺️ Roadmap

- ✅ **Phase 1 (current):** ICPs, Content Studio, Multi-project, Auth
- 🔜 **Phase 2:** SEO Tracker, Google Analytics integration
- 🔜 **Phase 3:** LinkedIn & Telegram automation, Content Calendar
- 🔜 **Phase 4:** Advanced analytics & reporting

---

© N5Deal — Internal marketing platform
