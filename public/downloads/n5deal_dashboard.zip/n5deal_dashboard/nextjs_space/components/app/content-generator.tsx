'use client'

import { useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { FileText, BookOpen, Linkedin, Send, Sparkles, Save, Copy, RotateCw, AlertCircle, Square } from 'lucide-react'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

interface Icp {
  id: string
  name: string
  industry: string
  painPoints: string[]
  goals: string[]
  budgetRange: string
  demographics: string
}

const TYPES = [
  { key: 'article', label: 'Article', icon: FileText, description: 'Long-form blog or SEO article' },
  { key: 'catalog', label: 'Catalog', icon: BookOpen, description: 'Product / service catalog entry' },
  { key: 'linkedin', label: 'LinkedIn', icon: Linkedin, description: 'Short-form LinkedIn post' },
  { key: 'telegram', label: 'Telegram', icon: Send, description: 'Short channel update / digest' },
] as const

const TONES = [
  'Expert, tech, B2B',
  'Informational, authoritative',
  'Friendly, conversational',
  'Concise, news-style',
  'Bold, punchy, founder-to-founder',
]

interface Props {
  defaultType?: string
  icps: Icp[]
}

export function ContentGenerator({ defaultType = 'linkedin', icps }: Props) {
  const router = useRouter()
  const [type, setType] = useState<string>(TYPES.some((t) => t.key === defaultType) ? defaultType : 'linkedin')
  const [topic, setTopic] = useState('')
  const [targetAudience, setTargetAudience] = useState('')
  const [keyMessages, setKeyMessages] = useState('')
  const [tone, setTone] = useState<string>(TONES[0])
  const [icpId, setIcpId] = useState<string>('')

  const [brief, setBrief] = useState('')
  const [streaming, setStreaming] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const abortRef = useRef<AbortController | null>(null)

  const onIcpChange = (id: string) => {
    setIcpId(id)
    const icp = icps?.find((i) => i?.id === id)
    if (icp) {
      if (!targetAudience.trim()) {
        setTargetAudience(`${icp?.name}${icp?.industry ? ` — ${icp.industry}` : ''}`)
      }
    }
  }

  const handleGenerate = async () => {
    if (!topic.trim() || !targetAudience.trim()) {
      toast.error('Topic and target audience are required')
      return
    }
    setError(null)
    setBrief('')
    setStreaming(true)
    const controller = new AbortController()
    abortRef.current = controller
    try {
      const res = await fetch('/api/content/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contentType: type, topic, targetAudience, keyMessages, tone, icpId: icpId || null }),
        signal: controller.signal,
      })
      if (!res.ok || !res.body) {
        const data = await res.json().catch(() => ({}))
        throw new Error(data?.error ?? 'Failed to start generation')
      }
      const reader = res.body.getReader()
      const decoder = new TextDecoder()
      let buffer = ''
      let partial = ''
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        partial += decoder.decode(value, { stream: true })
        const lines = partial.split('\n')
        partial = lines.pop() ?? ''
        for (const line of lines) {
          if (!line.startsWith('data: ')) continue
          const data = line.slice(6)
          if (data === '[DONE]') continue
          try {
            const parsed = JSON.parse(data)
            if (parsed?.status === 'processing' && typeof parsed?.delta === 'string') {
              buffer += parsed.delta
              setBrief(buffer)
            } else if (parsed?.status === 'completed') {
              if (typeof parsed?.result === 'string') {
                buffer = parsed.result
                setBrief(buffer)
              }
            } else if (parsed?.status === 'error') {
              throw new Error(parsed?.message ?? 'Generation failed')
            }
          } catch (e) {
            // keep going
          }
        }
      }
      toast.success('Brief generated')
    } catch (e: any) {
      if (e?.name === 'AbortError') {
        toast.info('Generation stopped')
      } else {
        setError(e?.message ?? 'Generation failed')
        toast.error(e?.message ?? 'Generation failed')
      }
    } finally {
      setStreaming(false)
      abortRef.current = null
    }
  }

  const handleStop = () => {
    try {
      abortRef.current?.abort?.()
    } catch {}
  }

  const handleSave = async () => {
    if (!brief.trim()) {
      toast.error('Nothing to save')
      return
    }
    setSaving(true)
    try {
      const res = await fetch('/api/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contentType: type,
          topic,
          targetAudience,
          keyMessages,
          tone,
          generatedBrief: brief,
        }),
      })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) {
        toast.error(data?.error ?? 'Could not save')
        return
      }
      toast.success('Brief saved')
      router.push(`/content/${data?.content?.id}`)
      router.refresh()
    } finally {
      setSaving(false)
    }
  }

  const copy = async () => {
    try {
      await navigator.clipboard?.writeText?.(brief ?? '')
      toast.success('Copied')
    } catch {
      toast.error('Could not copy')
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-5">
      {/* Left rail — form */}
      <div className="lg:col-span-2 space-y-5">
        <div className="bg-card border border-border shadow-sm p-5">
          <h3 className="font-display font-semibold text-lg tracking-tight">Format</h3>
          <p className="text-xs text-muted-foreground mt-0.5">Pick the content type.</p>
          <div className="mt-4 grid grid-cols-2 gap-2">
            {TYPES.map((t) => {
              const Icon = t.icon
              const active = type === t.key
              return (
                <button
                  key={t.key}
                  type="button"
                  onClick={() => setType(t.key)}
                  className={cn(
                    'flex flex-col items-start gap-1 p-3 text-left transition-colors',
                    active
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary hover:bg-secondary/70 text-foreground'
                  )}
                >
                  <Icon className="h-4 w-4" />
                  <span className="font-medium text-sm">{t.label}</span>
                  <span className={cn('text-[11px]', active ? 'text-primary-foreground/70' : 'text-muted-foreground')}>
                    {t.description}
                  </span>
                </button>
              )
            })}
          </div>
        </div>

        <div className="bg-card border border-border shadow-sm p-5 space-y-4">
          <h3 className="font-display font-semibold text-lg tracking-tight">Brief</h3>

          <div className="space-y-2">
            <Label htmlFor="topic">Topic *</Label>
            <Input
              id="topic"
              required
              placeholder="e.g. Why ready-made PI licenses save 6 months"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="icp">Linked ICP (optional)</Label>
            <select
              id="icp"
              value={icpId}
              onChange={(e) => onIcpChange(e.target.value)}
              className="h-10 w-full px-3 text-sm bg-background border border-input focus:outline-none focus:ring-2 focus:ring-ring"
            >
              <option value="">— None —</option>
              {(icps ?? []).map((i) => (
                <option key={i?.id} value={i?.id}>
                  {i?.name}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="audience">Target audience *</Label>
            <Input
              id="audience"
              required
              placeholder="e.g. Payment Startup founders in EU"
              value={targetAudience}
              onChange={(e) => setTargetAudience(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="keyMessages">Key messages</Label>
            <Textarea
              id="keyMessages"
              rows={3}
              placeholder="Main points to convey…"
              value={keyMessages}
              onChange={(e) => setKeyMessages(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="tone">Tone</Label>
            <select
              id="tone"
              value={tone}
              onChange={(e) => setTone(e.target.value)}
              className="h-10 w-full px-3 text-sm bg-background border border-input focus:outline-none focus:ring-2 focus:ring-ring"
            >
              {TONES.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>

          <div className="flex gap-2 pt-2">
            {streaming ? (
              <Button type="button" variant="outline" onClick={handleStop} className="w-full">
                <Square className="h-4 w-4" /> Stop
              </Button>
            ) : (
              <Button type="button" onClick={handleGenerate} className="w-full">
                <Sparkles className="h-4 w-4" />
                {brief ? 'Regenerate' : 'Generate brief'}
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Right rail — output */}
      <div className="lg:col-span-3">
        <div className="bg-card border border-border shadow-sm flex flex-col min-h-[560px]">
          <div className="flex items-center justify-between px-5 py-4 border-b border-border">
            <div>
              <h3 className="font-display font-semibold text-lg tracking-tight">Generated brief</h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                Streams live from AI. You can edit before saving.
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" onClick={copy} disabled={!brief || streaming}>
                <Copy className="h-3.5 w-3.5" /> Copy
              </Button>
              <Button variant="ghost" size="sm" onClick={handleGenerate} disabled={streaming || !topic || !targetAudience}>
                <RotateCw className="h-3.5 w-3.5" /> Regenerate
              </Button>
            </div>
          </div>

          {error ? (
            <div className="m-5 flex items-start gap-2 bg-destructive/10 text-destructive p-3 text-sm">
              <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          ) : null}

          <div className="flex-1 p-5">
            {brief ? (
              <Textarea
                value={brief}
                onChange={(e) => setBrief(e.target.value)}
                rows={22}
                className="font-mono text-sm leading-relaxed"
              />
            ) : (
              <div className="h-full min-h-[400px] flex flex-col items-center justify-center text-center">
                <div className="flex h-12 w-12 items-center justify-center bg-secondary">
                  <Sparkles className={cn('h-6 w-6 text-muted-foreground', streaming && 'animate-pulse')} />
                </div>
                <h4 className="mt-4 font-display font-semibold tracking-tight">
                  {streaming ? 'Generating your brief…' : 'Your brief will appear here'}
                </h4>
                <p className="mt-1 text-sm text-muted-foreground max-w-sm">
                  {streaming
                    ? 'Streaming tokens from the AI model. You can stop at any time.'
                    : 'Fill in the format and brief details on the left, then click generate.'}
                </p>
              </div>
            )}
          </div>

          <div className="flex items-center justify-end gap-2 px-5 py-4 border-t border-border">
            <Button
              variant="outline"
              onClick={() => {
                setBrief('')
                setError(null)
              }}
              disabled={!brief || streaming}
            >
              Clear
            </Button>
            <Button onClick={handleSave} disabled={!brief || streaming} loading={saving}>
              <Save className="h-4 w-4" /> Save brief
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
