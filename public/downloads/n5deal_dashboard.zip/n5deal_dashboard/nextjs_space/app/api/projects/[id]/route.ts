import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

async function getAdminMembership(userId: string, projectId: string) {
  return prisma.projectMember.findUnique({
    where: { projectId_userId: { projectId, userId } },
  })
}

export async function PUT(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  const userId = session?.user?.id as string | undefined
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const membership = await getAdminMembership(userId, params.id)
  if (!membership || membership.role !== 'admin') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }
  try {
    const body = await req.json()
    const project = await prisma.project.update({
      where: { id: params.id },
      data: {
        name: String(body?.name ?? '').trim() || undefined,
        companyName: String(body?.companyName ?? '').trim() || undefined,
        description: body?.description ?? null,
      },
    })
    return NextResponse.json({ project })
  } catch (err) {
    console.error('update project error', err)
    return NextResponse.json({ error: 'Could not update project' }, { status: 500 })
  }
}
