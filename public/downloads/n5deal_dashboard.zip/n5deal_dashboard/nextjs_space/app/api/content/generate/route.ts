import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { getOrCreateCurrentProject } from '@/lib/project'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'
export const maxDuration = 60

const BRIEF_TEMPLATES: Record<string, string> = {
  article: `Produce an **Article Brief** with these sections:
- Title (SEO-optimized, under 60 chars)
- Meta description (under 155 chars)
- Target keyword + 3 related keywords
- Target word count and reading level
- Outline as H2/H3 with 1-line description each (aim for 5–7 sections)
- 3 hook / intro angle options
- Internal linking ideas (at least 3)
- Primary CTA
- Compliance / tone notes`,
  catalog: `Produce a **Catalog Brief** (product/service card) with:
- Product/asset name
- One-line positioning statement (benefit-led)
- Target persona (who buys it)
- 3 key differentiators (bullet points)
- Specs / attributes (structured list)
- Use cases (2–3 scenarios)
- FAQ (3 Q&A)
- Primary CTA + secondary CTA`,
  linkedin: `Produce a **LinkedIn Post Brief** with:
- Hook (first 2 lines, must stop the scroll)
- Body outline (3–5 bullet points, punchy)
- Data or credibility element
- CTA (single, specific)
- Recommended hashtags (3–5) and hashtags to avoid
- Visual suggestion (carousel / image / none)
- Tone & style notes`,
  telegram: `Produce a **Telegram Post Brief** with:
- Format (digest / news / opinion)
- Max character count (aim for ≤ 800)
- Opening emoji hook line
- Body structure (3–5 short bullets, no fluff)
- Source / credibility note (if applicable)
- Single CTA with link placeholder
- Forbidden phrases / tone warnings`,
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  const userId = session?.user?.id as string | undefined
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  if (!process.env.ABACUSAI_API_KEY) {
    return NextResponse.json({ error: 'AI API key is not configured on the server' }, { status: 500 })
  }

  let body: any
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 })
  }

  const contentType = String(body?.contentType ?? 'linkedin')
  const topic = String(body?.topic ?? '').trim()
  const targetAudience = String(body?.targetAudience ?? '').trim()
  const keyMessages = String(body?.keyMessages ?? '').trim()
  const tone = String(body?.tone ?? '').trim()
  const icpId = body?.icpId ? String(body.icpId) : null

  if (!topic || !targetAudience) {
    return NextResponse.json({ error: 'Topic and target audience are required' }, { status: 400 })
  }

  const template = BRIEF_TEMPLATES[contentType] ?? BRIEF_TEMPLATES.article

  const project = await getOrCreateCurrentProject(userId)
  let icpContext = ''
  if (icpId) {
    const icp = await prisma.iCP.findUnique({ where: { id: icpId } })
    if (icp && icp.projectId === project.id) {
      icpContext = `\n\n### Linked ICP: ${icp.name}\n- Industry: ${icp.industry}\n- Company size: ${icp.companySize}\n- Pain points: ${(icp.painPoints ?? []).join('; ') || 'n/a'}\n- Goals: ${(icp.goals ?? []).join('; ') || 'n/a'}\n- Budget: ${icp.budgetRange || 'n/a'}\n- Demographics: ${icp.demographics || 'n/a'}\n- Decision process: ${icp.decisionProcess || 'n/a'}`
    }
  }

  const systemPrompt = `You are an experienced B2B marketing strategist producing structured content briefs for the N5Deal marketing team. Return clean, practical Markdown briefs with clear headings, short lines, and actionable detail. Never invent data; if something is unknown, write "TBD". Keep tone ${tone || 'expert, tech, B2B'}. Avoid hype, avoid advice language ("we recommend", "you should"), prefer informational / descriptive wording.`

  const userPrompt = `${template}\n\n### Topic\n${topic}\n\n### Target audience\n${targetAudience}\n\n### Key messages\n${keyMessages || '(none provided — infer sensible ones from the topic)'}\n\n### Tone\n${tone || 'expert, tech, B2B'}${icpContext}\n\nRespond with clean Markdown only. No preamble, no apologies.`

  const encoder = new TextEncoder()

  const stream = new ReadableStream({
    async start(controller) {
      const send = (obj: any) => {
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(obj)}\n\n`))
      }

      let heartbeat: any = null

      try {
        const upstream = await fetch('https://apps.abacus.ai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${process.env.ABACUSAI_API_KEY}`,
          },
          body: JSON.stringify({
            model: 'gpt-5.4-mini',
            messages: [
              { role: 'system', content: systemPrompt },
              { role: 'user', content: userPrompt },
            ],
            stream: true,
            max_tokens: 2500,
          }),
        })

        if (!upstream.ok || !upstream.body) {
          const text = await upstream.text().catch(() => '')
          send({ status: 'error', message: `LLM upstream error: ${upstream.status} ${text.slice(0, 200)}` })
          controller.close()
          return
        }

        // heartbeat to keep proxies happy
        heartbeat = setInterval(() => {
          try {
            controller.enqueue(encoder.encode(`: ping\n\n`))
          } catch {}
        }, 10000)

        const reader = upstream.body.getReader()
        const decoder = new TextDecoder()
        let partialRead = ''
        let fullText = ''

        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          partialRead += decoder.decode(value, { stream: true })
          const lines = partialRead.split('\n')
          partialRead = lines.pop() ?? ''
          for (const line of lines) {
            const trimmed = line.trim()
            if (!trimmed.startsWith('data:')) continue
            const data = trimmed.slice(5).trim()
            if (data === '[DONE]') {
              send({ status: 'completed', result: fullText })
              continue
            }
            try {
              const parsed = JSON.parse(data)
              const delta: string = parsed?.choices?.[0]?.delta?.content ?? ''
              if (delta) {
                fullText += delta
                send({ status: 'processing', delta })
              }
            } catch {
              // ignore
            }
          }
        }

        // final flush in case DONE marker never came
        send({ status: 'completed', result: fullText })
        controller.enqueue(encoder.encode(`data: [DONE]\n\n`))
      } catch (err: any) {
        console.error('generation stream error', err)
        try {
          send({ status: 'error', message: err?.message ?? 'Generation failed' })
        } catch {}
      } finally {
        if (heartbeat) clearInterval(heartbeat)
        try {
          controller.close()
        } catch {}
      }
    },
  })

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    },
  })
}
