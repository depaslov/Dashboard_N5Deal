import { NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const email = String(body?.email ?? '').toLowerCase().trim()
    const password = String(body?.password ?? '')
    const name = String(body?.name ?? '').trim()

    if (!email || !password || !name) {
      return NextResponse.json({ error: 'Missing fields' }, { status: 400 })
    }
    if (password.length < 8) {
      return NextResponse.json({ error: 'Password must be at least 8 characters' }, { status: 400 })
    }

    const existing = await prisma.user.findUnique({ where: { email } })
    if (existing) {
      return NextResponse.json({ error: 'Email already in use' }, { status: 409 })
    }

    const passwordHash = await bcrypt.hash(password, 10)
    const user = await prisma.user.create({
      data: { email, passwordHash, name, role: 'user' },
    })

    // Create a default project for the new user
    const project = await prisma.project.create({
      data: {
        name: `${name}'s Workspace`,
        companyName: 'My Company',
        description: 'Default workspace',
        ownerId: user.id,
      },
    })
    await prisma.projectMember.create({
      data: { projectId: project.id, userId: user.id, role: 'admin' },
    })

    return NextResponse.json({ ok: true, userId: user.id })
  } catch (err) {
    console.error('signup error', err)
    return NextResponse.json({ error: 'Internal error' }, { status: 500 })
  }
}
