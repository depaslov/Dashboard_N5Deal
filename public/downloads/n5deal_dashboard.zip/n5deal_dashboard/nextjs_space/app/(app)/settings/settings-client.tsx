'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { toast } from 'sonner'
import { User, Building2, Users, UserPlus, Save, Trash2, Shield } from 'lucide-react'
import { format } from 'date-fns'

interface User { id: string; name: string; email: string }
interface Project { id: string; name: string; companyName: string; description: string }
interface Member {
  id: string
  userId: string
  role: string
  name: string
  email: string
  createdAt: string
}

interface Props {
  user: User
  project: Project
  myRole: string
  members: Member[]
}

export function SettingsClient({ user, project, myRole, members }: Props) {
  const router = useRouter()

  // profile
  const [name, setName] = useState(user?.name ?? '')
  const [savingProfile, setSavingProfile] = useState(false)

  // project
  const [projName, setProjName] = useState(project?.name ?? '')
  const [companyName, setCompanyName] = useState(project?.companyName ?? '')
  const [description, setDescription] = useState(project?.description ?? '')
  const [savingProject, setSavingProject] = useState(false)

  // invite
  const [inviteEmail, setInviteEmail] = useState('')
  const [inviteRole, setInviteRole] = useState('member')
  const [inviting, setInviting] = useState(false)
  const [removingId, setRemovingId] = useState<string | null>(null)

  const isAdmin = myRole === 'admin'

  const saveProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    setSavingProfile(true)
    try {
      const res = await fetch('/api/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name }),
      })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) {
        toast.error(data?.error ?? 'Could not update profile')
        return
      }
      toast.success('Profile updated')
      router.refresh()
    } finally {
      setSavingProfile(false)
    }
  }

  const saveProject = async (e: React.FormEvent) => {
    e.preventDefault()
    setSavingProject(true)
    try {
      const res = await fetch(`/api/projects/${project.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: projName, companyName, description }),
      })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) {
        toast.error(data?.error ?? 'Could not update project')
        return
      }
      toast.success('Workspace updated')
      router.refresh()
    } finally {
      setSavingProject(false)
    }
  }

  const invite = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!inviteEmail.trim()) return
    setInviting(true)
    try {
      const res = await fetch(`/api/projects/${project.id}/members`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: inviteEmail.trim(), role: inviteRole }),
      })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) {
        toast.error(data?.error ?? 'Could not add member')
        return
      }
      toast.success('Member added')
      setInviteEmail('')
      router.refresh()
    } finally {
      setInviting(false)
    }
  }

  const removeMember = async (memberId: string) => {
    if (!confirm('Remove this member?')) return
    setRemovingId(memberId)
    try {
      const res = await fetch(`/api/projects/${project.id}/members/${memberId}`, { method: 'DELETE' })
      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        toast.error(data?.error ?? 'Could not remove member')
        return
      }
      toast.success('Member removed')
      router.refresh()
    } finally {
      setRemovingId(null)
    }
  }

  return (
    <div className="space-y-8">
      {/* Profile */}
      <section className="bg-card border border-border shadow-sm">
        <div className="px-6 py-4 border-b border-border flex items-center gap-2">
          <User className="h-4 w-4 text-muted-foreground" />
          <h2 className="font-display font-semibold text-lg tracking-tight">Your profile</h2>
        </div>
        <form onSubmit={saveProfile} className="p-6 grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="name">Full name</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" value={user?.email ?? ''} disabled />
          </div>
          <div className="md:col-span-2 flex justify-end">
            <Button type="submit" loading={savingProfile}>
              <Save className="h-4 w-4" /> Save profile
            </Button>
          </div>
        </form>
      </section>

      {/* Workspace */}
      <section className="bg-card border border-border shadow-sm">
        <div className="px-6 py-4 border-b border-border flex items-center gap-2">
          <Building2 className="h-4 w-4 text-muted-foreground" />
          <h2 className="font-display font-semibold text-lg tracking-tight">Workspace</h2>
        </div>
        <form onSubmit={saveProject} className="p-6 grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="projName">Workspace name</Label>
            <Input id="projName" value={projName} onChange={(e) => setProjName(e.target.value)} disabled={!isAdmin} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="companyName">Company</Label>
            <Input id="companyName" value={companyName} onChange={(e) => setCompanyName(e.target.value)} disabled={!isAdmin} required />
          </div>
          <div className="md:col-span-2 space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea id="description" rows={3} value={description} onChange={(e) => setDescription(e.target.value)} disabled={!isAdmin} />
          </div>
          {isAdmin ? (
            <div className="md:col-span-2 flex justify-end">
              <Button type="submit" loading={savingProject}>
                <Save className="h-4 w-4" /> Save workspace
              </Button>
            </div>
          ) : (
            <p className="md:col-span-2 text-xs text-muted-foreground">Only workspace admins can edit these fields.</p>
          )}
        </form>
      </section>

      {/* Team */}
      <section className="bg-card border border-border shadow-sm">
        <div className="px-6 py-4 border-b border-border flex items-center gap-2">
          <Users className="h-4 w-4 text-muted-foreground" />
          <h2 className="font-display font-semibold text-lg tracking-tight">Team</h2>
        </div>
        <div className="p-6 space-y-6">
          {isAdmin ? (
            <form onSubmit={invite} className="flex flex-wrap items-end gap-3">
              <div className="flex-1 min-w-[220px] space-y-2">
                <Label htmlFor="inviteEmail">Invite by email</Label>
                <Input
                  id="inviteEmail"
                  type="email"
                  placeholder="teammate@company.com"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="inviteRole">Role</Label>
                <select
                  id="inviteRole"
                  value={inviteRole}
                  onChange={(e) => setInviteRole(e.target.value)}
                  className="h-10 px-3 text-sm bg-background border border-input focus:outline-none focus:ring-2 focus:ring-ring"
                >
                  <option value="member">Member</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
              <Button type="submit" loading={inviting}>
                <UserPlus className="h-4 w-4" /> Add member
              </Button>
            </form>
          ) : null}

          <div>
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold mb-2">
              Members ({members?.length ?? 0})
            </p>
            <div className="border border-border divide-y divide-border">
              {(members ?? []).map((m) => (
                <div key={m?.id} className="flex items-center gap-4 px-4 py-3">
                  <div className="flex h-8 w-8 items-center justify-center bg-accent text-accent-foreground text-xs font-semibold">
                    {m?.name?.[0]?.toUpperCase?.() ?? '?'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">
                      {m?.name} {m?.userId === user?.id ? <span className="text-xs text-muted-foreground font-normal">(you)</span> : null}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">{m?.email}</p>
                  </div>
                  <span className="inline-flex items-center gap-1 text-[11px] uppercase tracking-widest bg-secondary px-2 py-1 font-semibold">
                    <Shield className="h-3 w-3" />
                    {m?.role}
                  </span>
                  <span className="hidden md:block text-xs text-muted-foreground">
                    Since {m?.createdAt ? format(new Date(m.createdAt), 'MMM d, yyyy') : ''}
                  </span>
                  {isAdmin && m?.userId !== user?.id ? (
                    <Button
                      variant="ghost"
                      size="icon-sm"
                      onClick={() => removeMember(m?.id)}
                      disabled={removingId === m?.id}
                      aria-label="Remove member"
                      className="text-muted-foreground hover:text-destructive"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  ) : null}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
