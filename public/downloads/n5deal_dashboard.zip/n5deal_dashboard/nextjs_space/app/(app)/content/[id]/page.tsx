import Link from 'next/link'
import { notFound } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { assertProjectAccess } from '@/lib/project'
import { PageHeader } from '@/components/app/page-header'
import { Button } from '@/components/ui/button'
import { ArrowLeft, FileText, BookOpen, Linkedin, Send, Clock } from 'lucide-react'
import { ContentActions } from './content-actions'
import { format } from 'date-fns'

export const dynamic = 'force-dynamic'

const TYPES: Record<string, { label: string; icon: any }> = {
  article: { label: 'Article', icon: FileText },
  catalog: { label: 'Catalog', icon: BookOpen },
  linkedin: { label: 'LinkedIn Post', icon: Linkedin },
  telegram: { label: 'Telegram Post', icon: Send },
}

export default async function ContentDetailPage({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  const userId = session?.user?.id as string
  const content = await prisma.generatedContent.findUnique({
    where: { id: params.id },
    include: { createdBy: true },
  })
  if (!content) notFound()
  const canAccess = await assertProjectAccess(userId, content.projectId)
  if (!canAccess) notFound()

  const meta = TYPES[content.contentType] ?? TYPES.article
  const Icon = meta.icon

  return (
    <div className="max-w-[900px] mx-auto">
      <div className="mb-4">
        <Button asChild variant="ghost" size="sm">
          <Link href="/content" className="gap-1">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to Content Studio
          </Link>
        </Button>
      </div>

      <PageHeader
        title={content.topic}
        description={`${meta.label} brief for ${content.targetAudience}`}
        actions={<ContentActions id={content.id} brief={content.generatedBrief} topic={content.topic} />}
      />

      <div className="grid gap-6 md:grid-cols-3">
        <aside className="md:col-span-1 space-y-4">
          <div className="bg-card border border-border shadow-sm p-5">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center bg-primary text-primary-foreground">
                <Icon className="h-5 w-5" />
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold">
                  Format
                </p>
                <p className="text-sm font-semibold">{meta.label}</p>
              </div>
            </div>
            <div className="mt-5 space-y-3 text-sm">
              <Meta label="Target audience" value={content.targetAudience} />
              <Meta label="Tone" value={content.tone} />
              <Meta label="Key messages" value={content.keyMessages} />
              <Meta label="Created by" value={content?.createdBy?.name ?? '—'} />
              <div>
                <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold">
                  Created at
                </p>
                <p className="mt-0.5 text-sm inline-flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {format(new Date(content.createdAt), 'MMM d, yyyy • HH:mm')}
                </p>
              </div>
            </div>
          </div>
        </aside>

        <section className="md:col-span-2 bg-card border border-border shadow-sm p-6">
          <h2 className="font-display font-semibold text-lg tracking-tight">Generated brief</h2>
          <pre className="mt-4 whitespace-pre-wrap font-sans text-sm leading-relaxed text-foreground">
{content.generatedBrief}
          </pre>
        </section>
      </div>
    </div>
  )
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold">{label}</p>
      <p className="mt-0.5 text-sm text-foreground whitespace-pre-wrap">{value || '—'}</p>
    </div>
  )
}
