import Link from 'next/link'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { getOrCreateCurrentProject } from '@/lib/project'
import { PageHeader } from '@/components/app/page-header'
import { Button } from '@/components/ui/button'
import { ContentListClient } from './content-list-client'
import { Plus } from 'lucide-react'

export const dynamic = 'force-dynamic'

export default async function ContentPage() {
  const session = await getServerSession(authOptions)
  const userId = session?.user?.id as string
  const project = await getOrCreateCurrentProject(userId)

  const contents = await prisma.generatedContent.findMany({
    where: { projectId: project.id },
    orderBy: { createdAt: 'desc' },
    include: { createdBy: true },
  })

  return (
    <div className="max-w-[1200px] mx-auto">
      <PageHeader
        title="Content Studio"
        description="Generate and archive structured content briefs for articles, catalogs, LinkedIn and Telegram."
        actions={
          <Button asChild>
            <Link href="/content/new" className="gap-2">
              <Plus className="h-4 w-4" /> New brief
            </Link>
          </Button>
        }
      />
      <ContentListClient
        items={contents.map((c: any) => ({
          id: c.id,
          contentType: c.contentType,
          topic: c.topic,
          targetAudience: c.targetAudience,
          tone: c.tone,
          createdAt: c.createdAt.toISOString(),
          createdByName: c?.createdBy?.name ?? '',
        }))}
      />
    </div>
  )
}
