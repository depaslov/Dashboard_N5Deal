import Link from 'next/link'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { getOrCreateCurrentProject } from '@/lib/project'
import { PageHeader } from '@/components/app/page-header'
import { Button } from '@/components/ui/button'
import { ContentGenerator } from '@/components/app/content-generator'
import { ArrowLeft } from 'lucide-react'

export const dynamic = 'force-dynamic'

export default async function NewContentPage({ searchParams }: { searchParams: { type?: string } }) {
  const session = await getServerSession(authOptions)
  const userId = session?.user?.id as string
  const project = await getOrCreateCurrentProject(userId)
  const icps = await prisma.iCP.findMany({
    where: { projectId: project.id },
    orderBy: { createdAt: 'asc' },
    select: { id: true, name: true, industry: true, painPoints: true, goals: true, budgetRange: true, demographics: true },
  })

  const defaultType = (searchParams?.type ?? 'linkedin') as string

  return (
    <div className="max-w-[1200px] mx-auto">
      <div className="mb-4">
        <Button asChild variant="ghost" size="sm">
          <Link href="/content" className="gap-1">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to Content Studio
          </Link>
        </Button>
      </div>
      <PageHeader
        title="Generate a new brief"
        description="Pick a format, describe your context and let AI draft the structured brief."
      />
      <ContentGenerator
        defaultType={defaultType}
        icps={icps.map((i: any) => ({
          id: i.id,
          name: i.name,
          industry: i.industry,
          painPoints: i.painPoints ?? [],
          goals: i.goals ?? [],
          budgetRange: i.budgetRange,
          demographics: i.demographics,
        }))}
      />
    </div>
  )
}
