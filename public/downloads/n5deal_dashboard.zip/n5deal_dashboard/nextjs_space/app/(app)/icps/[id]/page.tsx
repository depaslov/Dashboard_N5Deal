import Link from 'next/link'
import { notFound } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { assertProjectAccess } from '@/lib/project'
import { PageHeader } from '@/components/app/page-header'
import { Button } from '@/components/ui/button'
import { IcpForm } from '@/components/app/icp-form'
import { ArrowLeft } from 'lucide-react'

export const dynamic = 'force-dynamic'

export default async function EditIcpPage({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  const userId = session?.user?.id as string
  const icp = await prisma.iCP.findUnique({ where: { id: params.id } })
  if (!icp) notFound()
  const canAccess = await assertProjectAccess(userId, icp.projectId)
  if (!canAccess) notFound()

  return (
    <div className="max-w-[900px] mx-auto">
      <div className="mb-4">
        <Button asChild variant="ghost" size="sm">
          <Link href="/icps" className="gap-1">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to ICPs
          </Link>
        </Button>
      </div>
      <PageHeader
        title={icp.name}
        description="Edit this ideal customer profile. Changes will apply to new content briefs."
      />
      <IcpForm
        mode="edit"
        icp={{
          id: icp.id,
          name: icp.name,
          industry: icp.industry,
          companySize: icp.companySize,
          painPoints: icp.painPoints,
          goals: icp.goals,
          demographics: icp.demographics,
          budgetRange: icp.budgetRange,
          decisionProcess: icp.decisionProcess,
        }}
      />
    </div>
  )
}
