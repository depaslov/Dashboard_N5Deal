# 🛠️ Local Setup Guide — N5Deal Dashboard

This guide walks you through running the N5Deal AI Marketing Dashboard on your own machine (macOS / Windows / Linux).

---

## 📋 Prerequisites

Install these on your machine first:

| Tool | Min version | Install link |
|------|-------------|--------------|
| **Node.js** | 18.17+ (recommended: 20 LTS) | https://nodejs.org/ |
| **Yarn** | 1.22+ | `npm install -g yarn` |
| **PostgreSQL** | 14+ | https://www.postgresql.org/download/ |
| **Git** | any | https://git-scm.com/ |

### Verify installation

```bash
node -v      # v20.x.x or higher
yarn -v      # 1.22.x or higher
psql --version    # psql (PostgreSQL) 14.x or higher
git --version
```

> **Windows users:** we recommend using **WSL2** (Ubuntu) for a smoother experience. Install via `wsl --install` in PowerShell as admin.

---

## 1️⃣ Get the Code

If you have the project as a folder (exported from this session):

```bash
cd /path/to/n5deal_dashboard
```

If you want to put it in a Git repo of your own:

```bash
cd /path/to/n5deal_dashboard
git init
git add .
git commit -m "Initial commit — N5Deal Dashboard"
# (optional) push to GitHub / GitLab
```

---

## 2️⃣ Install Dependencies

```bash
cd nextjs_space
yarn install
```

This will install ~105 packages. Should take 1–3 minutes.

---

## 3️⃣ Set Up PostgreSQL

You have **three options** — pick the one that suits you best.

### Option A — Local PostgreSQL (recommended for development)

**macOS** (Homebrew):
```bash
brew install postgresql@16
brew services start postgresql@16
```

**Ubuntu / Debian**:
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
```

**Windows**: download the installer from https://www.postgresql.org/download/windows/

**Create a database:**
```bash
# Connect to Postgres
psql postgres

# Inside psql prompt:
CREATE DATABASE n5deal_dashboard;
CREATE USER n5deal WITH ENCRYPTED PASSWORD 'your_strong_password';
GRANT ALL PRIVILEGES ON DATABASE n5deal_dashboard TO n5deal;
\q
```

Your `DATABASE_URL` will be:
```
postgresql://n5deal:your_strong_password@localhost:5432/n5deal_dashboard?schema=public
```

### Option B — Supabase (free, cloud-hosted)

1. Go to https://supabase.com/ → create a new project
2. In the dashboard, open **Settings → Database → Connection string (URI)**
3. Copy the string — it looks like `postgresql://postgres:[YOUR-PASSWORD]@db.xxx.supabase.co:5432/postgres`

### Option C — Neon (free, serverless)

1. Go to https://neon.tech/ → create a new project
2. Copy the **Connection string** from the dashboard

---

## 4️⃣ Configure Environment Variables

Copy the example file and edit it:

```bash
cp .env.example .env
```

Open `.env` in your editor and fill in the values:

```env
# PostgreSQL connection string (from step 3)
DATABASE_URL="postgresql://n5deal:your_password@localhost:5432/n5deal_dashboard?schema=public"

# NextAuth — generate a random secret (see below)
NEXTAUTH_SECRET="paste-generated-secret-here"
NEXTAUTH_URL="http://localhost:3000"

# Abacus.AI API key (for Content Studio)
ABACUSAI_API_KEY="your-abacus-ai-key"
```

### Generate a NEXTAUTH_SECRET

**macOS / Linux / WSL:**
```bash
openssl rand -base64 32
```

**Windows PowerShell:**
```powershell
[Convert]::ToBase64String((1..32 | ForEach-Object { Get-Random -Minimum 0 -Maximum 256 }))
```

Or use an online generator: https://generate-secret.vercel.app/32

### Get an Abacus.AI API key

1. Sign up at https://abacus.ai/
2. Navigate to **API Keys** in your account settings
3. Create a new key and paste it into `ABACUSAI_API_KEY`

> **Note:** Without this key, AI content generation in the Content Studio will not work. Everything else (ICP management, projects, auth) will still function.

---

## 5️⃣ Set Up the Database Schema

```bash
# Generate the Prisma Client
yarn prisma generate

# Create all tables in your database
yarn prisma db push

# (Optional) Seed with sample N5Deal data
yarn prisma db seed
```

If seeding was successful, you'll have:
- 1 admin user (`john@doe.com` / `johndoe123`)
- 1 project (`N5Deal Marketing`)
- 4 sample ICPs (EMI, MSB, VASP, PI buyers)
- 3 sample content briefs

---

## 6️⃣ Run the Development Server

```bash
yarn dev
```

You should see:
```
▲ Next.js 14.2.28
  - Local:        http://localhost:3000
```

Open **http://localhost:3000** in your browser.

### Sign in with the default admin:
```
Email:    john@doe.com
Password: johndoe123
```

---

## 7️⃣ Verify Everything Works

- [ ] Landing page loads at `/`
- [ ] Sign in with `john@doe.com` / `johndoe123`
- [ ] Redirects to `/dashboard` — you see stat cards
- [ ] `/icps` shows 4 sample ICPs
- [ ] `/content` shows 3 sample briefs
- [ ] `/settings` shows project + member management
- [ ] Create a new ICP — it appears in the list
- [ ] Open Content Studio and generate a test brief (requires `ABACUSAI_API_KEY`)

---

## 🔧 Useful Commands

```bash
# View the database visually in your browser
yarn prisma studio
# → opens at http://localhost:5555

# Re-sync Prisma schema after changes
yarn prisma db push

# Reset the database (WARNING: deletes all data)
yarn prisma migrate reset

# Run in production mode
yarn build && yarn start

# Run linting
yarn lint
```

---

## 🐞 Troubleshooting

### "Can't reach database server"
- Ensure PostgreSQL is running: `brew services list` (macOS) or `sudo systemctl status postgresql` (Linux)
- Check the `DATABASE_URL` format: `postgresql://user:password@host:port/db?schema=public`
- Try connecting manually: `psql "$DATABASE_URL"`

### "PrismaClientInitializationError: Environment variable not found: DATABASE_URL"
- `.env` file must be in `nextjs_space/` directory (same level as `package.json`)
- Restart `yarn dev` after editing `.env`

### "Hydration failed" / "Text content does not match"
- Delete `.next` folder and restart: `rm -rf .next && yarn dev`

### Port 3000 already in use
```bash
# Run on a different port
PORT=3001 yarn dev
```

### Yarn install fails
```bash
# Clear cache and reinstall
rm -rf node_modules yarn.lock
yarn cache clean
yarn install
```

### TypeScript errors about `@prisma/client`
```bash
yarn prisma generate
```

---

## 🚢 Deploying to Production

When you're ready to deploy:

### Vercel (easiest)
1. Push your repo to GitHub
2. Import at https://vercel.com/new
3. Add the same env variables in Vercel's project settings
4. Make sure your `DATABASE_URL` points to a production Postgres (Supabase / Neon / Railway)
5. Deploy — Vercel handles the build & hosting

### Self-hosted / VPS
```bash
yarn build
yarn start   # runs on port 3000 by default
```

Use a reverse proxy (Nginx / Caddy) + PM2 or systemd for process management.

---

## 💬 Need help?

- Open `ARCHITECTURE.md` for technical deep-dives
- Check `nextjs_space/STYLE_GUIDE.md` for UI conventions
- All Prisma docs: https://www.prisma.io/docs
- Next.js App Router docs: https://nextjs.org/docs
