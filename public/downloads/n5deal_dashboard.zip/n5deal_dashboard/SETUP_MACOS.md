# 🍎 macOS Setup Guide — N5Deal Dashboard

Повна покрокова інструкція для запуску проєкту на macOS. Протестовано на **macOS Sonoma / Sequoia** (Intel та Apple Silicon).

---

## ⏱️ Загальний час: ~20 хвилин

| Крок | Час |
|-----|-----|
| Homebrew + залежності | 5–10 хв |
| PostgreSQL налаштування | 2 хв |
| `yarn install` | 2–3 хв |
| `.env` та база даних | 2 хв |
| Перший запуск | 1 хв |

---

## КРОК 1 — Встановіть Homebrew

Відкрийте **Terminal** (Cmd + Space → "Terminal") і вставте:

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

Після встановлення виконайте команди, які Homebrew підкаже (зазвичай 2 рядки з `echo ... >> ~/.zprofile`), щоб додати `brew` у ваш PATH.

Перевірте:
```bash
brew --version
# Homebrew 4.x.x
```

> 💡 Якщо Homebrew вже встановлено — пропускайте цей крок.

---

## КРОК 2 — Встановіть Node.js, Yarn, PostgreSQL, Git

**Одна команда ставить усе:**

```bash
brew install node@20 yarn postgresql@16 git
```

Після встановлення виконайте:

```bash
# Підключити node@20 до PATH (Homebrew не лінкує його автоматично)
brew link --overwrite node@20 --force

# Перевірити версії
node -v        # повинно бути v20.x.x
yarn -v        # 1.22.x
psql --version # psql 16.x
git --version  # 2.x
```

> Якщо `node -v` не показує v20, перезапустіть Terminal або додайте в `~/.zshrc`:
> ```bash
> export PATH="/opt/homebrew/opt/node@20/bin:$PATH"   # Apple Silicon
> export PATH="/usr/local/opt/node@20/bin:$PATH"      # Intel Mac
> ```

---

## КРОК 3 — Запустіть PostgreSQL

```bash
# Запустити як background-сервіс (автозапуск при старті Mac)
brew services start postgresql@16

# Перевірити, що працює
brew services list
# postgresql@16    started    ubuntu   ~/Library/LaunchAgents/homebrew.mxcl.postgresql@16.plist
```

### Додати `psql` до PATH

```bash
# Apple Silicon (M1/M2/M3/M4)
echo 'export PATH="/opt/homebrew/opt/postgresql@16/bin:$PATH"' >> ~/.zshrc

# АБО Intel Mac
echo 'export PATH="/usr/local/opt/postgresql@16/bin:$PATH"' >> ~/.zshrc

# Перечитати конфіг
source ~/.zshrc
```

### Створіть базу даних та користувача

```bash
# Відкрити psql (перший раз залогиниться під вашим macOS-юзером)
psql postgres
```

У `psql` prompt виконайте:
```sql
CREATE DATABASE n5deal_dashboard;
CREATE USER n5deal WITH ENCRYPTED PASSWORD 'n5deal_dev_2026';
GRANT ALL PRIVILEGES ON DATABASE n5deal_dashboard TO n5deal;
ALTER DATABASE n5deal_dashboard OWNER TO n5deal;
\q
```

> 🔐 Замініть `n5deal_dev_2026` на свій пароль, якщо хочете. Запам'ятайте його — знадобиться в `.env`.

**Перевірка підключення:**
```bash
psql "postgresql://n5deal:n5deal_dev_2026@localhost:5432/n5deal_dashboard"
# → повинен відкритись prompt:  n5deal_dashboard=>
# Вийти: \q
```

---

## КРОК 4 — Розпакуйте проєкт

1. **Завантажте ZIP** → https://c0921b28e.preview.abacusai.app/downloads/n5deal_dashboard.zip
2. Розпакуйте:

```bash
cd ~/Downloads
unzip n5deal_dashboard.zip -d ~/Projects/
cd ~/Projects/n5deal_dashboard/nextjs_space
```

> 💡 Необов'язково — папку `Projects` можна замінити на будь-яку іншу (наприклад, `~/Code/`).

---

## КРОК 5 — Встановіть залежності

у папці `nextjs_space`:

```bash
yarn install
```

Займе 2–3 хвилини, встановить ~105 пакетів. На macOS іноді з'являються warnings про `node-gyp` чи нативні модулі — це нормально, якщо в кінці бачите:
```
✨  Done in 146.82s.
```

---

## КРОК 6 — Налаштуйте `.env`

```bash
cp .env.example .env
```

Відкрийте `.env` у будь-якому редакторі (я рекомендую VS Code):
```bash
open -a "Visual Studio Code" .env
# або просто:
nano .env
```

Заповніть так:

```env
DATABASE_URL="postgresql://n5deal:n5deal_dev_2026@localhost:5432/n5deal_dashboard?schema=public"

NEXTAUTH_SECRET="<згенеруйте командою нижче>"
NEXTAUTH_URL="http://localhost:3000"

ABACUSAI_API_KEY="<ваш Abacus.AI ключ>"
```

### Згенеруйте `NEXTAUTH_SECRET`

```bash
openssl rand -base64 32
```
Скопіюйте вивід у `NEXTAUTH_SECRET`.

### Отримайте `ABACUSAI_API_KEY`

1. Зареєструйтесь на https://abacus.ai/
2. **Account** → **API Keys** → **Create New Key**
3. Скопіюйте ключ у `.env`

> 💡 Без цього ключа всі модулі працюватимуть окрім **Content Studio AI Generation**.

---

## КРОК 7 — Ініціалізуйте базу даних

```bash
# Згенерувати Prisma Client
yarn prisma generate

# Створити всі таблиці в БД
yarn prisma db push

# Заповнити тестовими даними
yarn prisma db seed
```

Після seed-у у вас буде:
- **1 адмін:** `john@doe.com` / `johndoe123`
- **1 проєкт:** `N5Deal Marketing`
- **4 ICP профілі:** EMI, MSB, VASP, PI buyers
- **3 приклади контенту** в історії

---

## КРОК 8 — Запустіть додаток

```bash
yarn dev
```

Ви побачите:
```
▲ Next.js 14.2.28
  - Local:        http://localhost:3000
  ✓ Ready in 2.3s
```

Відкрийте в браузері: **http://localhost:3000**

Увійдіть:
```
Email:    john@doe.com
Password: johndoe123
```

---

## ✅ Чек-лист перевірки

- [ ] Landing-сторінка відкривається на `/`
- [ ] Логін працює, редиректить на `/dashboard`
- [ ] У Dashboard видно stat cards з числами
- [ ] `/icps` — показує 4 ICP профілі
- [ ] `/content` — показує 3 згенерованих брифи
- [ ] `/settings` — видно управління командою
- [ ] Створення нового ICP працює
- [ ] **Content Studio** генерує AI-бриф (потрібен `ABACUSAI_API_KEY`)

---

## 🔧 Корисні macOS команди

```bash
# Візуальний редактор БД у браузері (http://localhost:5555)
yarn prisma studio

# Перезапустити PostgreSQL
brew services restart postgresql@16

# Зупинити PostgreSQL (не витрачає батарею на Mac)
brew services stop postgresql@16

# Логи PostgreSQL
tail -f /opt/homebrew/var/log/postgresql@16.log   # Apple Silicon
tail -f /usr/local/var/log/postgresql@16.log      # Intel

# Скинути базу (УВАГА: стирає всі дані!)
yarn prisma migrate reset

# Зупинити Next.js dev server
Ctrl + C  (в терміналі де запущено)

# Якщо порт 3000 зайнятий
lsof -ti:3000 | xargs kill -9
# або запустити на іншому порту:
PORT=3001 yarn dev
```

---

## 🐞 Troubleshooting (macOS-specific)

### ❌ `command not found: brew`
Додайте Homebrew у PATH (після встановлення він підкаже, як саме):
```bash
echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile   # Apple Silicon
source ~/.zprofile
```

### ❌ `psql: command not found`
```bash
brew link postgresql@16 --force
# або явно через PATH:
export PATH="/opt/homebrew/opt/postgresql@16/bin:$PATH"
```

### ❌ `Error: P1001: Can't reach database server`
```bash
# 1) Перевірте, що Postgres запущено
brew services list

# 2) Перевірте з'єднання вручну
psql "postgresql://n5deal:n5deal_dev_2026@localhost:5432/n5deal_dashboard"

# 3) Перезапустіть сервіс
brew services restart postgresql@16
```

### ❌ `FATAL: role "n5deal" does not exist`
Виконайте `CREATE USER ...` з **Кроку 3** ще раз:
```bash
psql postgres
```
```sql
CREATE USER n5deal WITH ENCRYPTED PASSWORD 'n5deal_dev_2026';
GRANT ALL PRIVILEGES ON DATABASE n5deal_dashboard TO n5deal;
ALTER DATABASE n5deal_dashboard OWNER TO n5deal;
\q
```

### ❌ `yarn: command not found` після `brew install yarn`
```bash
brew link yarn
# АБО
npm install -g yarn
```

### ❌ `node-gyp` / нативні модулі не компілюються
Встановіть Xcode Command Line Tools:
```bash
xcode-select --install
```

### ❌ Apple Silicon: `Error: incompatible architecture`
Переконайтеся, що весь Homebrew нативний (arm64), а не під Rosetta:
```bash
which brew      # має бути /opt/homebrew/bin/brew (Apple Silicon)
arch            # має показати arm64 якщо ви в нативному terminal
```

### ❌ `ECONNREFUSED 127.0.0.1:5432`
Postgres не запущений:
```bash
brew services start postgresql@16
```

### ❌ "Hydration failed" або дивні UI-помилки
```bash
rm -rf .next node_modules/.cache
yarn dev
```

### ❌ Port 3000 зайнятий іншим процесом
```bash
lsof -ti:3000 | xargs kill -9
yarn dev
```

---

## 💻 VS Code — рекомендовані розширення

```bash
# Встановіть VS Code, якщо ще немає
brew install --cask visual-studio-code

# Відкрити проєкт
cd ~/Projects/n5deal_dashboard
code .
```

**Обов'язкові extensions:**
- **Prisma** (офіційне) — підсвітка `schema.prisma`
- **Tailwind CSS IntelliSense** — autocomplete Tailwind-класів
- **ESLint** — лінтинг
- **Prettier** — форматування
- **TypeScript** (вбудовано)

---

## 🔄 Що робити при наступному запуску (daily workflow)

```bash
cd ~/Projects/n5deal_dashboard/nextjs_space
yarn dev
```

**Ось і все!** PostgreSQL на macOS запускається автоматично з brew services.

Якщо ви перезавантажували Mac і щось не працює:
```bash
brew services start postgresql@16
yarn dev
```

---

## 🚀 Production build на Mac (для тесту)

```bash
yarn build
yarn start
```
Відкриється на `http://localhost:3000` з production-оптимізованою збіркою.

---

## ✨ Bonus: Корисні macOS aliases

Додайте у `~/.zshrc`:

```bash
# N5Deal shortcuts
alias n5="cd ~/Projects/n5deal_dashboard/nextjs_space"
alias n5dev="cd ~/Projects/n5deal_dashboard/nextjs_space && yarn dev"
alias n5db="cd ~/Projects/n5deal_dashboard/nextjs_space && yarn prisma studio"
alias n5pg-restart="brew services restart postgresql@16"
```

Після чого:
```bash
source ~/.zshrc
n5dev     # одна команда запускає весь dev-сервер
```

---

## ❓ FAQ

**Q: Чи потрібен Docker?**
Ні. Postgres працює напряму через Homebrew.

**Q: Чи працює на Apple Silicon (M1/M2/M3/M4)?**
Так, повністю сумісно. Homebrew і Node.js обидва мають нативні arm64 версії.

**Q: Чи можна без локального Postgres використати Supabase/Neon?**
Так — просто підставте їх `DATABASE_URL` в `.env`. Решта кроків ідентична.

**Q: Як оновити залежності пізніше?**
```bash
cd ~/Projects/n5deal_dashboard/nextjs_space
yarn upgrade-interactive --latest
```

**Q: Чи безпечно комітити `.env` у Git?**
❌ **НІ!** `.gitignore` вже блокує це. Ніколи не пушіть `.env` у публічні репозиторії.

---

## 📞 Застрягли?

Напишіть мені, на якому саме кроці — я допоможу діагностувати. Для повного списку помилок див. розділ **Troubleshooting** вище.

---

© N5Deal — macOS Setup Guide (Phase 1 MVP)
